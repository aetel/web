import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import signal

plt.rcParams.update({
	"font.size": 9, "axes.grid": True, "grid.alpha": 0.3,
	"axes.spines.top": False, "axes.spines.right": False,
	"figure.dpi": 150, "savefig.bbox": "tight",
})
B, R, G, O, K = "#1f4e9c", "#c0392b", "#2e8b57", "#e67e22", "#444444"

def save(name):
	plt.savefig("fig/" + name + ".pdf")
	plt.close()

def step(num, den, t):
	return signal.step(signal.TransferFunction(num, den), T=t)[1]

# 1. error en RP: tipo 0 escalon, tipo 1 rampa
t = np.linspace(0, 8, 800)
fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.7))
c0 = 0.75 * (1 - np.exp(-4 * t))
ax[0].plot(t, np.ones_like(t), "--", c=K, label="entrada $r$ (escal\u00f3n)")
ax[0].plot(t, c0, c=B, label="salida $c$")
ax[0].annotate("", xy=(6, 1), xytext=(6, 0.75), arrowprops=dict(arrowstyle="<->", color=R))
ax[0].text(6.15, 0.86, "error\n$=\\frac{1}{1+K_0}$", color=R, fontsize=8, va="center")
ax[0].set_title("Tipo 0: $CA=3/(s+1)$, $K_0=3$")
ax[0].set_xlabel("t [s]"); ax[0].set_ylim(0, 1.25); ax[0].legend(loc="lower right", fontsize=7)
tt = np.linspace(0, 12, 1200)
tl, y, _ = signal.lsim(signal.TransferFunction([1], [1, 1, 1]), tt, tt)
ax[1].plot(tt, tt, "--", c=K, label="entrada $r$ (rampa)")
ax[1].plot(tt, y, c=B, label="salida $c$")
ax[1].annotate("", xy=(10, 10), xytext=(10, 9), arrowprops=dict(arrowstyle="<->", color=R))
ax[1].text(10.2, 9.4, "error $=\\frac{A}{K_1}=1$", color=R, fontsize=8)
ax[1].set_title("Tipo 1: $CA=1/(s(s+1))$, $K_1=1$")
ax[1].set_xlabel("t [s]"); ax[1].legend(loc="upper left", fontsize=7)
save("error_rp")

# 2. tres tipos de respuesta
t = np.linspace(0, 8, 800)
fig, ax = plt.subplots(figsize=(5.6, 3))
ax.plot(t, step([2], [1, 3, 2], t), c=B, label="sobreamortiguada: polos $-1,-2$")
ax.plot(t, step([4], [1, 4, 4], t), c=G, label="cr\u00edtica: polo doble $-2$")
ax.plot(t, step([8], [1, 1, 8], t), c=R, label="subamortiguada: $-0.5\\pm 2.8j$")
ax.plot(t, 1 + 0 * t, ":", c=K)
ax.set_xlabel("t [s]"); ax.set_ylabel("$c(t)$ ante escal\u00f3n unitario")
ax.legend(fontsize=7, loc="lower right")
save("tres_tipos")

# 3. polo dominante
t = np.linspace(0, 6, 600)
fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.7))
ax[0].plot(t, np.exp(-t), c=B, label="$e^{-t}$ (polo $-1$, lento)")
ax[0].plot(t, np.exp(-20 * t), c=R, label="$e^{-20t}$ (polo $-20$, r\u00e1pido)")
ax[0].set_title("Los dos modos por separado"); ax[0].set_xlabel("t [s]"); ax[0].legend(fontsize=7)
ax[0].set_xlim(0, 4)
ax[1].plot(t, step([20], [1, 21, 20], t), c=B, lw=2, label="completo $\\frac{20}{(s+1)(s+20)}$")
ax[1].plot(t, 1 - np.exp(-t), "--", c=O, label="simplificado $\\frac{1}{s+1}$")
ax[1].set_title("Escal\u00f3n: casi id\u00e9nticos"); ax[1].set_xlabel("t [s]"); ax[1].legend(fontsize=7, loc="lower right")
save("dominante")

# 4. primer orden, ts
t = np.linspace(0, 5, 500)
fig, ax = plt.subplots(figsize=(5, 2.9))
ax.plot(t, 1 - np.exp(-t), c=B)
ax.axhline(1, c=K, ls=":"); ax.axhline(0.95, c=R, ls="--", lw=0.8); ax.axhline(0.632, c=G, ls="--", lw=0.8)
ax.plot([3, 3], [0, 0.95], c=R, ls="--", lw=0.8); ax.plot([1, 1], [0, 0.632], c=G, ls="--", lw=0.8)
ax.text(3.05, 0.1, "$t_s\\approx 3/|p|$\n(95 %)", color=R, fontsize=8)
ax.text(1.05, 0.1, "$1/|p|$\n(63 %)", color=G, fontsize=8)
ax.set_xlabel("t [s]"); ax.set_title("$M=1/(s+1)$, $p=-1$")
save("ts_primer_orden")

# 5. discreto primer orden: p>0 y p<0
k = np.arange(0, 21)
fig, ax = plt.subplots(1, 3, figsize=(7.4, 2.4), sharey=False)
for a, p, ttl in zip(ax, [0.8, 0.4, -0.6], ["$p=0.8$ (lenta)", "$p=0.4$ (r\u00e1pida)", "$p=-0.6$ (alterna)"]):
	c = (1 - p ** (k)) / (1 - p)  # escalon con K=1
	c = c / (1 / (1 - p))
	a.step(k, c, where="post", c=B); a.axhline(1, c=K, ls=":")
	a.set_title(ttl, fontsize=9); a.set_xlabel("k")
save("disc_primer_orden")

# 6. critico vs simple
t = np.linspace(0, 8, 800)
fig, ax = plt.subplots(figsize=(5.4, 2.9))
ax.plot(t, 1 - np.exp(-t), c=B, label="polo simple $-1$: $t_s\\approx3$ s")
ax.plot(t, step([1], [1, 2, 1], t), c=G, label="polo doble $-1$: $t_s\\approx4.8$ s")
ax.axhline(0.95, c=R, ls="--", lw=0.8); ax.plot([3, 3], [0, 0.95], c=B, ls="--", lw=0.8)
ax.plot([4.8, 4.8], [0, 0.95], c=G, ls="--", lw=0.8)
ax.set_xlabel("t [s]"); ax.legend(fontsize=7, loc="lower right")
save("critico_vs_simple")

# 7. subamortiguada anotada
t = np.linspace(0, 3, 1500)
y = step([20], [1, 4, 20], t)
fig, ax = plt.subplots(figsize=(6, 3.3))
ax.plot(t, y, c=B, lw=1.6)
env = 1 + np.exp(-2 * t) / np.sin(np.arctan2(4, -2)) * -1
ax.plot(t, 1 + 1.12 * np.exp(-2 * t), ":", c=O); ax.plot(t, 1 - 1.12 * np.exp(-2 * t), ":", c=O)
ax.text(1.9, 1.09, "envolvente $e^{\\mathrm{Re}[p]\\,t}$", color=O, fontsize=8)
ax.axhline(1, c=K, ls=":"); ax.axhline(1.05, c=R, ls="--", lw=0.7); ax.axhline(0.95, c=R, ls="--", lw=0.7)
tp = np.pi / 4; mp = np.exp(-np.pi * 2 / 4)
ax.plot([tp, tp], [0, 1 + mp], c=G, ls="--", lw=0.8)
ax.annotate("", xy=(tp + 0.02, 1 + mp), xytext=(tp + 0.02, 1), arrowprops=dict(arrowstyle="<->", color=G))
ax.text(tp + 0.08, 1.08, "$M_p=21\\,\\%$", color=G, fontsize=8)
ax.text(tp - 0.02, 0.05, "$t_p=T_d/2$", color=G, fontsize=8, ha="right")
ax.plot([np.pi / 2, np.pi / 2], [0, 0.95], c=R, ls="--", lw=0.8)
ax.text(np.pi / 2 + 0.04, 0.4, "$t_s=\\pi/|\\mathrm{Re}[p]|$", color=R, fontsize=8)
ax.annotate("", xy=(2 * tp, 0.55), xytext=(0, 0.55), arrowprops=dict(arrowstyle="<->", color=O))
ax.text(tp, 0.58, "$T_d$", color=O, fontsize=8, ha="center")
ax.set_xlabel("t [s]"); ax.set_title("$M=20/(s^2+4s+20)$, $p=-2\\pm4j$")
save("subamortiguada")

# 8. mover polos: Re cte (ts igual) / Im cte (Td igual)
t = np.linspace(0, 6, 1200)
fig, ax = plt.subplots(1, 2, figsize=(7.4, 2.8))
for im, col in zip([2, 4, 8], [B, G, R]):
	ax[0].plot(t, step([4 + im ** 2], [1, 4, 4 + im ** 2], t), c=col, label="Im$=\\pm%d$" % im)
ax[0].set_title("Re$[p]=-2$ fija: mismo $t_s$, sube $M_p$"); ax[0].legend(fontsize=7); ax[0].set_xlabel("t [s]")
for re, col in zip([0.5, 1, 2], [R, G, B]):
	ax[1].plot(t, step([re ** 2 + 9], [1, 2 * re, re ** 2 + 9], t), c=col, label="Re$=-%g$" % re)
ax[1].set_title("Im$[p]=\\pm3$ fija: mismo $T_d$, baja $t_s$"); ax[1].legend(fontsize=7); ax[1].set_xlabel("t [s]")
save("mover_polos")

# 9. discreto subamortiguado
k = np.arange(0, 121)
_, y = signal.dstep(signal.dlti([0.1], [1, -1.8, 0.9], dt=0.1), n=121)
y = y[0].flatten()
fig, ax = plt.subplots(figsize=(6, 3))
ax.step(k * 0.1, y, where="post", c=B)
ax.axhline(1, c=K, ls=":"); ax.axhline(1.05, c=R, ls="--", lw=0.7); ax.axhline(0.95, c=R, ls="--", lw=0.7)
ax.annotate("$M_p\\approx60\\,\\%$\n$t_p=1$ s ($k_p=10$)", xy=(1, y[10]), xytext=(2.5, 1.5), arrowprops=dict(arrowstyle="->", color=G), color=G, fontsize=8)
ax.set_xlabel("t [s]  ($T=0.1$ s)"); ax.set_title("$M(z)=0.1/(z^2-1.8z+0.9)$")
save("disc_subamortiguada")
print("ok")
